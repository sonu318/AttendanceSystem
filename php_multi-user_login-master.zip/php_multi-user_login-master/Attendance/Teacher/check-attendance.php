<?php include '../../user/admin/settings.php'; //include settings ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TEACHER</title>
    <link rel="stylesheet" a href="../../user/admin/css/bootstrap.css"/>
    <style>
      .navigation-bar ul {
        padding: 0px;
        margin: 0px;
        text-align: center;
        display:inline-block;
        vertical-align:top;
        margin-top: 35px;
      }
      li {
        display: inline;
      }
      ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
      }
      .button {
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
      }
      .button2 {background-color: #008CBA;} /* Blue */
      .green-btn:hover {
        background-color: #4CAF50;
        color: white;
      }
      .black-btn{
        background-color: grey;
      }
      .black-btn:hover {
        background-color: #555555;
        color: white;
      }
    </style>
  </head>
  <body>
    <!-- <h2>This is Teacher's page</h2> -->
    <!-- <h2>Hello: <?php $ufunc->UserName(); //Show name who is in session user?></h2> -->
    <div class="navigation-bar">
    <img id="logo" src="walchandlogo.jpg" alt="logo" style="width:150px;height:100px;margin-right:200px;margin-top:20px;"> 
      <ul>
        <li><a href="../../user/admin/index.php"><button class="button button2 green-btn" style="margin-left: 100px;">Home</button></a></li>
        <li><a href="../../user/admin/add_user.php"><button class="button button2 green-btn">Add User</button></a></li>
        <li><a href="chech-attendance.php"><button class="button green-btn">Check Attendance</button></a></li>
        <li><a href="../../user/admin/view.php"><button class="button button2 green-btn">Check Database</button></a></li>
        <li><a href="../../includes/logout.php"><button class="button button2 black-btn">Logout</button></a></li>
      </ul>
    </div>
    <hr>
    <div>
      <h2>Attendance Management System</h2>
    </div>
  </body>
</html>
