# Multi-user login script with PHP
Multi-user login with PHP and MySQL

### Prerequisites

Edit `connect.php` and enjoy! 🙂

```
includes/connect.php
```

### Example MySQL (DB) file

```
DB/phpmultiuserlogin.sql
```
```
Admin: admin@admin.com | 123
User: user@user.com | 123
```
