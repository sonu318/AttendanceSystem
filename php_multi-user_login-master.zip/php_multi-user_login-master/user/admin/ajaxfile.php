<?php
include 'db.php';
include 'studentdb.php';

## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value

## Custom Field value
$searchByName = $_POST['searchByName'];
$searchByYear = $_POST['searchByYear'];
$searchByBranch = $_POST['searchByBranch'];

## Search 
$searchQuery = " ";
if($searchByName != ''){
   $searchQuery .= " and (name like '%".$searchByName."%' ) ";
}
if($searchByYear != ''){
   $searchQuery .= " and (year='".$searchByYear."') ";
}
if($searchByBranch != ''){
   $searchQuery .= " and (branch='".$searchByBranch."') ";
}
if($searchValue != ''){
   $searchQuery .= " and (name like '%".$searchValue."%' or 
      login like '%".$searchValue."%' or 
      year like'%".$searchValue."%' or 
      branch like'%".$searchValue."%') ";
}

## Total number of records without filtering
$sel = mysqli_query($conn,"select count(*) as allcount from users");
$records = mysqli_fetch_assoc($sel);
$totalRecords = $records['allcount'];

## Total number of records with filtering
$sel = mysqli_query($conn,"select count(*) as allcount from users WHERE 1 ".$searchQuery);
$records = mysqli_fetch_assoc($sel);
$totalRecordwithFilter = $records['allcount'];

## Fetch records
$empQuery = "select * from users WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
$empRecords = mysqli_query($conn, $empQuery);
$data = array();

while ($row = mysqli_fetch_assoc($empRecords)) {
   $data[] = array(
      "id"=>$row['id'],
      "prn"=>$row['prn'],
     "name"=>$row['name'],
     "login"=>$row['login'],
     "year"=>$row['year'],
     "branch"=>$row['branch']
   );
}

## Response
$response = array(
  "draw" => intval($draw),
  "iTotalRecords" => $totalRecords,
  "iTotalDisplayRecords" => $totalRecordwithFilter,
  "aaData" => $data
);

echo json_encode($response);