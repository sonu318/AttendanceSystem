<?php

    require_once("db.php");

    if(isset($_POST['submit']))
    {
        if(empty($_POST['name']) || empty($_POST['email']))
        {
            echo'<script>alert("Please check your query...")
            window.location.href = "add_user.php";
            </script>';
        }
        else
        {
            // $UserID = $_POST['id'];
            $UserName = $_POST['name'];
            // $UserPrn = $_POST['prn'];
            $UserEmail = $_POST['email'];
            $UserPassword = md5($_POST['email']);
            // $UserImage = $_POST['image'];
            // $UserYear = $_POST['year'];
            // $UserBranch = $_POST['branch'];

            $query = " insert into users (name, login , password, role) values('$UserName','$UserEmail','$UserPassword', '1')";
            $result = mysqli_query($conn,$query);

            if($result)
            {
                echo'<script>
                alert("Data inserted Successfully")
                window.location.href = "add_user.php";
                </script>';
                //header("location:view.php");
            }
            else
            {
                echo'<script>alert("Please check your query...")
                window.location.href = "add_user.php";
                </script>';
            }
        }
        // header("location:view.php");
    }
    else
    {
        header("location:add_user.php");
    }
?>