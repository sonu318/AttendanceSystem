<?php 
    include 'settings.php';
    require_once("db.php");
    $query = " select id, name, prn,login,year,branch from users where role='0'";
    $result = mysqli_query($conn,$query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" a href="css/bootstrap.css"/>
    <!-- <link rel="stylesheet" a href="Datatables/datatables.min.css"/> -->
    <!-- <link rel="script" a href="Datatables/datatables.min.js"/> -->
    <!-- Datatable CSS -->
    <!-- <link href='https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'> -->

    <!-- jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- Datatable JS -->
    <!-- <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script> -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.css"/>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.js"></script>

    <title>View Records</title>
    <style>
        #mylist {
            background-position: 8px 8px;
            background-repeat: no-repeat;
            width: 10%;
            font-size: 15px;
            padding: 0px 10px 0px 10px;
            border: 1px solid #ddd;
            margin-bottom: 8px;
            /* margin-right: 200px; */
            margin-left: 200px;
        }
        /* .h6{
            margin-left: 200px;
        } */
    </style>
</head>
<body>  
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for roll no..">
<!-- <div>        
<table id="empTable">
            <tr>
                <td>
                    <input type='text' id='searchByName' placeholder='Enter name'>
                </td>
                <td>
                    <select id='searchByYear'>
                        <option value=''>-- Select Year--</option>
                        <option value='first'>First Year</option>
                        <option value='second'>Second Year</option>
                        <option value='third'>Third Year</option>
                        <option value='fourth'>Fourth Year</option>
                    </select>
                </td>
                <td>
                    <select id='searchByBranch'>
                        <option value=''>-- Select Branch--</option>
                        <option value='cse'>CSE</option>
                        <option value='it'>IT</option>
                        <option value='mechanical'>MECHANICAL</option>
                        <option value='civil'>CIVIL</option>
                        <option value='electrical'>ELECTRICAL</option>
                        <option value='electronics'>ELECTRONICS</option>
                    </select>
                </td>
            </tr>
        </table>
        </div> -->

        <div class="container">
            <div class="row">
                <div class="col m-auto">
                    <div class="card mt-5">
                        <table class="table table-bordered" id='myTable'>
                            <tr>
                                <th> User ID </th>
                                <th> User PRN </th>
                                <th> User Name</th>
                                <th> User Email </th>
                                <th> Year </th>
                                <th> Branch </th>
                                <th> Edit  </th>
                                <th> Delete </th>
                            </tr>

                            <?php 
                                while($row=mysqli_fetch_assoc($result))
                                    {
                                        $UserID = $row['id'];
                                        $UserPrn = $row['prn'];
                                        $UserName = $row['name'];
                                        $UserEmail = $row['login'];
                                        $UserYear = $row['year'];
                                        $UserBranch = $row['branch'];
                                        // $UserMobile = $row['password'];
                            ?>
                                    <tr>
                                        <th><?php echo $UserID ?></th>
                                        <td><?php echo $UserPrn ?></td>
                                        <td><?php echo $UserName ?></td>
                                        <td><?php echo $UserEmail ?></td>
                                        <td><?php echo $UserYear ?></td>
                                        <td><?php echo $UserBranch ?></td>
                                       
                                        <td><a href="display.php?GetID=<?php echo $UserID ?>">Edit</a></td>
                                        <td><a href="delete.php?Del=<?php echo $UserID ?>">Delete</a></td>
                                    </tr>        
                            <?php 
                                    }  
                            ?>                                                                  
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- <script>
        $(document).ready(function(){
            var dataTable = $('#empTable').DataTable({
                'processing': true,
                'serverSide': true,
                'serverMethod': 'post',
                //'searching': false, // Remove default Search Control
                'ajax': {
                    'url':'ajaxfile.php',
                    'data': function(data){
                        // Read values
                        var year = $('#searchByYear').val();
                        var branch = $('#searchByBranch').val();
                        var name = $('#searchByName').val();

                        // Append to data
                        data.searchByName = name;
                        data.searchByYear = year;
                        data.searchByBranch = branch;
                        
                    }
                },
                'columns': [
                    { data: 'id' },
                    { data: 'prn' }, 
                    { data: 'name' }, 
                    { data: 'login' },
                    { data: 'year' },
                    { data: 'branch' },
                ]
            });

                $('#searchByName').keyup(function(){
                    dataTable.draw();
                });

                $('#searchByYear').change(function(){
                    dataTable.draw();
                });
                $('#searchByBranch').change(function(){
                    dataTable.draw();
                });
            });
            </script> -->
            <!-- <script>
	function myFunction() {
	  // Declare variables
	  var input, filter, table, tr, td, i, txtValue;
	  input = document.getElementById("myInput");
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");

	  // Loop through all table rows, and hide those who don't match the search query
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[0];
		if (td) {
		  txtValue = td.textContent || td.innerText;
		  if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}
	  }
	}
	</script> -->
    <script>
	function myFunction() {
	  // Declare variables
	  var input, filter, table, tr, td, i, txtValue;
	  input = document.getElementById("myInput");
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");

	  // Loop through all table rows, and hide those who don't match the search query
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[0];
		if (td) {
		  txtValue = td.textContent || td.innerText;
		  if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}
	  }
	}
	</script>
</body>
</html>