<?php 
    include 'settings.php';
    require_once("db.php");
    $query = " select id, name, login from users where role='1'";
    $result = mysqli_query($conn,$query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" a href="css/bootstrap.css"/>
    <title>View Records</title>
</head>
<body class="bg-white">

        <div class="container">
            <div class="row">
                <div class="col m-auto">
                    <div class="card mt-5">
                        <table class="table table-bordered">
                            <tr>
                                <td><b> User ID </b></td>
                                <td><b> User Name </b></td>
                                <!-- <td><b> User PRN </b></td> -->
                                <td><b> User Email </b></td>
                                <td><b> Edit  </b></td>
                                <td><b> Delete </b></td>
                            </tr>

                            <?php 
                                    
                                    while($row=mysqli_fetch_assoc($result))
                                    {
                                        $UserID = $row['id'];
                                        $UserName = $row['name'];
                                        // $UserPrn = $row['prn'];
                                        $UserEmail = $row['login'];
                                        // $UserMobile = $row['password'];
                            ?>
                                    <tr>
                                        <td><?php echo $UserID ?></td>
                                        <td><?php echo $UserName ?></td>
                                        <!-- <td><?php echo $UserPrn ?></td> -->
                                        <td><?php echo $UserEmail ?></td>
                                        <!-- <td><?php echo $UserMobile ?></td> -->
                                        <td><a href="display.php?GetID=<?php echo $UserID ?>">Edit</a></td>
                                        <td><a href="delete.php?Del=<?php echo $UserID ?>">Delete</a></td>
                                    </tr>        
                            <?php 
                                    }  
                            ?>                                                                    
                                   

                        </table>
                    </div>
                </div>
            </div>
        </div>
    
</body>
</html>