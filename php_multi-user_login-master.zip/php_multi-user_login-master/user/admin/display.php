<?php include 'settings.php'; //include settings ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TEACHER</title>
    <style>
      .navigation-bar ul {
        padding: 0px;
        margin: 0px;
        text-align: center;
        display:inline-block;
        vertical-align:top;
        margin-top: 35px;
      }
      li {
        display: inline;
      }
      ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
      }
      .button {
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
      }
      .button2 {background-color: #008CBA;} /* Blue */
    </style>
  </head>
  <body>
    <!-- <h2>This is Teacher's page</h2> -->
    <!-- <h2>Hello: <?php $ufunc->UserName(); //Show name who is in session user?></h2> -->
    <div class="navigation-bar">
    <img id="logo" src="walchandlogo.jpg" alt="logo" style="width:150px;height:100px;margin-right:200px;margin-top:20px;"> 
      <ul>
        <li><a href="index.php"><button class="button button2">Home</button></a></li>
        <li><a href="contact.php"><button class="button button2">Add Student</button></a></li>
        <li><a href="view.php"><button class="button button2">Check Database</button></a></li>
        <li><a href="about.asp"><button class="button button2">Actions</button></a></li>
        <li><a href="../../includes/logout.php"><button class="button button2">Logout</button></a></li>
      </ul>
    </div>
    <hr>
    <div>
      <h2 style="text-align: center;">Update Information</h2>
    </div>
  </body>
</html>
<?php 

    require_once("db.php");
    $UserID = $_GET['GetID'];
    $query = " select * from users where role='0'";
    $result = mysqli_query($conn,$query);

    while($row=mysqli_fetch_assoc($result))
    {
        $UserID = $row['id'];
        $UserName = $row['name'];
        $UserPrn = $row['prn'];
        $UserEmail = $row['login'];
        // $UserMobile = $row['password'];
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" a href="css/bootstrap.css"/>
    <title>Document</title>
</head>
<body class="bg-white">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 m-auto">
                    <div class="card mt-5">
                        <div class="card-title">
                            <h3 class="bg-success text-white text-center py-3"> Update Form in PHP</h3>
                        </div>
                        <div class="card-body">

                            <form action="update.php?ID=<?php echo $UserID ?>" method="post">
                                <!-- <input type="text" class="form-control mb-2" placeholder=" User ID " name="od" value="<?php echo $UserID ?>"> -->
                                <input type="text" class="form-control mb-2" placeholder=" User Name " name="name" value="<?php echo $UserName ?>">
                                <input type="text" class="form-control mb-2" placeholder=" User PRN " name="prn" value="<?php echo $UserPrn ?>">
                                <input type="email" class="form-control mb-2" placeholder=" User Email " name="login" value="<?php echo $UserEmail ?>">
                                <!-- <input type="text" class="form-control mb-2" placeholder=" User Mobile " name="password" value="<?php echo $UserMobile ?>"> -->
                                <button class="btn btn-primary" name="update">Update</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    
</body>
</html>