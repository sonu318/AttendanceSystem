<?php include 'settings.php'; //include settings ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>USER</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" a href="css/bootstrap.css"/>
    <style>
      .navigation-bar ul {
        padding: 0px;
        margin: 0px;
        text-align: center;
        display:inline-block;
        vertical-align:top;
        margin-top: 35px;
      }
      li {
        display: inline;
      }
      ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
      }
      .button {
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
      }
      .button2 {background-color: #008CBA;} /* Blue */
      .green-btn:hover {
        background-color: #4CAF50;
        color: white;
      }
      .black-btn{
        background-color: grey;
      }
      .black-btn:hover {
        background-color: #555555;
        color: white;
      }
    </style>
  </head>
  <body>
    <!-- <h2>This is Teacher's page</h2> -->
    <!-- <h2>Hello: <?php $ufunc->UserName(); //Show name who is in session user?></h2> -->
    <div class="navigation-bar">
    <img id="logo" src="walchandlogo.jpg" alt="logo" style="width:150px;height:100px;margin-right:200px;margin-top:20px;"> 
    <ul>
        <li><a href="index.php"><button class="button button2 green-btn" style="margin-left: 100px;">Home</button></a></li>
        <li><a href="add_user.php"><button class="button green-btn">Add User</button></a></li>
        <li><a href="Filter and addstudent/Entry.php"><button class="button button2 green-btn">Check Attendance</button></a></li>
        <li><a href="view.php"><button class="button button2 green-btn">Check Database</button></a></li>
        <li><a href="../../includes/logout.php"><button class="button button2 black-btn">Logout</button></a></li>
      </ul>
      <!-- <a href="studentdb.php"><button class="button button2 green-btn" style="margin-left: 150px;">Home</button> -->
    </div>
    <hr>
    <div>
      <h2 style="text-align: center;">Database</h2>
    </div>
    <div class="w3-sidebar w3-light-grey w3-bar-block" style="width:15%">
      <h3 class="w3-bar-item">Menu</h3>
      <button type="button" style="margin-left: 16px; margin-bottom: 10px;" class="btn btn-success" data-bs-toggle="modal1" data-bs-target="#myModal1" style="margin-bottom: 10px;">Add New_Teacher</button>
      <button type="button" style="margin-left: 16px" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal" style="margin-bottom: 10px;">Add New_Student</button>
      <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">Add New_Teacher</button> -->
      <!-- <a href="teacherdb.php" class="w3-bar-item w3-button">Add Teacher</a> -->
      <!-- <a href="#" class="w3-bar-item w3-button">Link 3</a> -->
    </div>

    <form action="insert.php" method="post">
					<div class="container mt-5">
						<div class="modal" id="myModal">
							<div class="modal-dialog">
								<div class="modal-content">
									<!-- <div class="modal-header">
										<h5 class="modal-title">Add New_Student</h5>
										<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
									</div> -->
									<div class="modal-body">
										<!-- <form action="insert1.php" method="POST"> -->
                                        <!-- <div class="mb-3">
												<select class="form-select mb-3" name="type" 
													aria-label="Default select example">
													<option value="student" name="type">student</option>												
												</select>
											</div> -->
                                            <!-- <div class="mb-3">
												<label class="form-label required">Id</label>
												<input  class="form-control" name="Id" required>
											</div> -->
											<div class="mb-3">
											    <label class="form-label required">Name: </label>
											    <input class="form-control" name="name" required>
											</div>
											<div class="mb-3">
												<label class="form-label required">PRN/Roll no: </label>
												<input type="text" class="form-control" name="prn" required>
											</div>
											<div class="mb-3">
											<label class="form-label required">E-mail: </label>
											<input type="email" class="form-control" name="email" required>
											</div>
											<div class="mb-3">
												<label for="" class="control-label required">Image: </label><br>
												<input type="file" class="from-control" name="image" required>
											</div>
                      <div class="mb-3">
                        <label class="form-label required">Select Year:</label>
												<select class="form-select mb-3" name="year" aria-label="Default select example">
													<option value="First Year" name="year">First Year</option>
                          <option value="Second Year" name="year">Second Year</option>
                          <option value="Third Year" name="year">Third Year</option>
                          <option value="Fourth Year" name="year">Fourth Year</option>
												</select>
											</div>
                      <div class="mb-3">
                        <label class="form-label required">Select Branch:</label>
												<select class="form-select mb-3" name="branch" aria-label="Default select example">
													<option value="CSE" name="branch">CSE</option>
													<option value="IT" name="branch">IT</option>
                          <option value="CIVIL" name="branch">CIVIL</option>
                          <option value="MECHANICAL" name="branch">MECHANICAL</option>
                          <option value="ELECTRICAL" name="branch">ELECTRICAL</option>
                          <option value="ELECTRONICS" name="branch">ELECTRONICS</option>
												</select>
											</div>
										<!-- </form> -->
									</div>
									<div class="modal-footer">
										<input type="submit" name="submit" class="btnRegister btn btn-primary" value="save">
									</div>
								</div>
							</div>
						</div>
					</div>
					<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
				</form>
    <form action="insert1.php" method="post">
					<div class="container mt-5">
						<div class="modal1" id="myModal1">
							<div class="modal-dialog">
								<div class="modal-content">
									<!-- <div class="modal-header">
										<h5 class="modal-title">Add New_Student</h5>
										<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
									</div> -->
									<div class="modal-body">
										<!-- <form action="insert1.php" method="POST"> -->
                                        <!-- <div class="mb-3">
												<select class="form-select mb-3" name="type" 
													aria-label="Default select example">
													<option value="student" name="type">student</option>												
												</select>
											</div> -->
                                            <!-- <div class="mb-3">
												<label class="form-label required">Id</label>
												<input  class="form-control" name="Id" required>
											</div> -->
											<div class="mb-3">
											    <label class="form-label required">Name: </label>
											    <input class="form-control" name="name" required>
											</div>
											<!-- <div class="mb-3">
												<label class="form-label required">PRN/Roll no: </label>
												<input type="text" class="form-control" name="prn" required>
											</div> -->
											<div class="mb-3">
											<label class="form-label required">E-mail: </label>
											<input type="email" class="form-control" name="email" required>
											</div>
											<!-- <div class="mb-3">
												<label for="" class="control-label required">Image: </label><br>
												<input type="file" class="from-control" name="image" required>
											</div>
                      <div class="mb-3">
                        <label class="form-label required">Select Year:</label>
												<select class="form-select mb-3" name="year" aria-label="Default select example">
													<option value="First Year" name="year">First Year</option>
                          <option value="Second Year" name="year">Second Year</option>
                          <option value="Third Year" name="year">Third Year</option>
                          <option value="Fourth Year" name="year">Fourth Year</option>
												</select>
											</div>
                      <div class="mb-3">
                        <label class="form-label required">Select Branch:</label>
												<select class="form-select mb-3" name="branch" aria-label="Default select example">
													<option value="CSE" name="branch">CSE</option>
													<option value="IT" name="branch">IT</option>
                          <option value="CIVIL" name="branch">CIVIL</option>
                          <option value="MECHANICAL" name="branch">MECHANICAL</option>
                          <option value="ELECTRICAL" name="branch">ELECTRICAL</option>
                          <option value="ELECTRONICS" name="branch">ELECTRONICS</option>
												</select>
											</div> -->
										<!-- </form> -->
									</div>
									<div class="modal-footer">
										<input type="submit" name="submit" class="btnRegister btn btn-primary" value="save">
									</div>
								</div>
							</div>
						</div>
					</div>
					<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
				</form>


  </body>
</html>

