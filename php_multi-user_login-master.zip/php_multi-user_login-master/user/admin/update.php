<?php 

    require_once("db.php");

    if(isset($_POST['update']))
    {
        $UserID = $_GET['id'];
        $UserName = $_POST['name'];
        $UserPrn = $_POST['prn'];
        $UserEmail = $_POST['login'];
        $UserMobile = $_POST['password'];

        $query = " update users set name = '".$UserName."', prn = '".$UserPrn."', login='".$UserEmail."',password='".$UserMobile."' where id='".$UserID."'";
        $result = mysqli_query($conn,$query);

        if($result)
        {
            header("location:view.php");
        }
        else
        {
            echo ' Please Check Your Query ';
        }
    }
    else
    {
        header("location:view.php");
    }


?>