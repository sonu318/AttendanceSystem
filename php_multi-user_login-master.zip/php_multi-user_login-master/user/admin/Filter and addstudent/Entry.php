<?php 
  session_start();
  include "db_connect.php";
  $sub_sql="";
	$toDate=$fromDate="";
	if(isset($_POST['submit'])){
	$from=$_POST['from'];
	$fromDate=$from;
	$fromArr=explode("/",$from);
	$from=$fromArr['2'].'-'.$fromArr['1'].'-'.$fromArr['0'];
	$from=$from." 00:00:00";
	
	$to=$_POST['to'];
	$toDate=$to;
	$toArr=explode("/",$to);
	$to=$toArr['2'].'-'.$toArr['1'].'-'.$toArr['0'];
	$to=$to." 23:59:59";
	
	$sub_sql= " where Date >= '$from' && Date <= '$to' ";
}
$res=mysqli_query($conn,"SELECT * FROM entry1 INNER JOIN users ON entry1.Name = users.name $sub_sql order by Date desc");
// $res=mysqli_query($conn,"select * from entry1 $sub_sql order by Date desc");
   {?>
<!DOCTYPE html>
<html>
<head>
	<title>Attendance</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" a href="css/bootstrap.css"/>
    <style>
      .navigation-bar ul {
        padding: 0px;
        margin: 0px;
        text-align: center;
        display:inline-block;
        vertical-align:top;
        margin-top: 35px;
      }
      li {
        display: inline;
      }
      ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
      }
      .button {
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
      }
      .button2 {background-color: #008CBA;} /* Blue */
      .green-btn:hover {
        background-color: #4CAF50;
        color: white;
      }
      .black-btn{
        background-color: grey;
      }
      .black-btn:hover {
        background-color: #555555;
        color: white;
      }
    </style>
</head>
<body>
<div class="navigation-bar">
    <img id="logo" src="walchandlogo.jpg" alt="logo" style="width:150px;height:100px;margin-right:200px;margin-top:20px;"> 
    <ul>
        <li><a href="../index.php"><button class="button button2 green-btn" style="margin-left: 100px;">Home</button></a></li>
        <li><a href="../add_user.php"><button class="button button2 green-btn">Add User</button></a></li>
        <li><a href="Entry.php"><button class="button green-btn">Check Attendance</button></a></li>
        <li><a href="../view.php"><button class="button button2 green-btn">Check Database</button></a></li>
        <li><a href="../../../includes/logout.php"><button class="button button2 black-btn">Logout</button></a></li>
      </ul>
      <!-- <a href="studentdb.php"><button class="button button2 green-btn" style="margin-left: 150px;">Home</button> -->
    </div>
    <hr>
	<div class="container">
  <br/><h1 style="text-align: center;">Attendance</h1><br/>
  
  <div>
	<form method="post">
		<label for="from">From</label>
		<input type="text" id="from" name="from" required value="<?php echo $fromDate?>">
		<label for="to">to</label>
		<input type="text" id="to" name="to" required value="<?php echo $toDate?>">
		<input type="submit" name="submit" value="Filter">
	</form>
  </div>
  <br/><br/>
  <?php if(mysqli_num_rows($res)>0){?>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>PRN/Roll No.</th>
        <th>Name</th>
        <th>Date</th>
		<th>Time</th>
      </tr>
    </thead>
    <tbody>
      <?php 
	  $i =1;
	  while($row=mysqli_fetch_assoc($res)){?>
      <tr>
		<th scope="row"><?=$i?></th>
        <td><?php echo $row['prn']?></td>    
        <td><?php echo $row['Name']?></td>        
		    <td><?php echo $row['Date']?></td>
		    <td><?php echo $row['dtString']?></td>
      </tr>
	  <?php $i++; }?>
	  
    </tbody>
  </table>
  <?php } else {
	echo "No data found";  
  }
  ?>
</div>
<script>
  $( function() {
    var dateFormat = "dd/mm/yy",
      from = $( "#from" )
        .datepicker({
          defaultDate: "+1w",
          changeMonth: true,
          numberOfMonths: 1,
		  dateFormat:"dd/mm/yy",
        })
        .on( "change", function() {
          to.datepicker( "option", "minDate", getDate( this ) );
        }),
      to = $( "#to" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
		dateFormat:"dd/mm/yy",
      })
      .on( "change", function() {
        from.datepicker( "option", "maxDate", getDate( this ) );
      });
 
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }
  } );
  </script>
</body>
</html>
<?php }?>