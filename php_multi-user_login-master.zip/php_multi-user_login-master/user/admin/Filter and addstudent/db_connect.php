<?php 
$conn=mysqli_connect("localhost","root","","phpmultiuserlogin"); 
if(!$conn) { die(" Connection Error "); } 
?>